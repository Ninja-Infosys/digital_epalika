<?php

return [
    'name' => 'ListRegistration',
];
