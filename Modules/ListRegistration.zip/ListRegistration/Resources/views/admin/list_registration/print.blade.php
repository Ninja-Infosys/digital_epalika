@extends('admin.layouts.master')
@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item">
                            <a href="{{route('admin.dashboard')}}">
                                <img class="icon me-1" src="{{asset('assets/backend/images/home.svg')}}"
                                     alt="document-icon">
                                गृहपृष्ठ
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{route('admin.listRegistrations.listRegistration.index')}}"> मौजुदा सुची
                                दर्ता </a>
                        </li>
                        <li class="breadcrumb-item active">प्रमाणपत्र प्रिन्ट</li>
                    </ol>
                </div>
                <h4 class="page-title">प्रमाणपत्र प्रिन्ट </h4>
            </div>
        </div>
    </div>
    <div class="d-flex justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center justify-content-between">
                        <h4 class="header-title mb-0">प्रमाणपत्र प्रिन्ट</h4>
                        <x-print-button
                            target-element="print"
                            title="प्रमाणपत्र"
                        />
                    </div>
                </div>
                <div class="card-body">
                    <div id="print" class="certificate"
                         style="border-image: url({{asset('assets/backend/border.png')}}) 30 stretch">
                        <div class="lh-lg font-15 position-relative">
                            {!! letterHead() !!}
                            <div class="position-absolute top-0 end-0">
                                <img src="#" height="80" width="90" alt=""/>
                            </div>
                            <div class="d-flex justify-content-between mt-3">
                                <div>
                                    </div>
                                <div class="certificate-title">
                                    <h3> मौजुदा सुची दर्ताप्रमाण-पत्र</h3>
                                </div>
                                <div>
                                    sdfsdfsdfsdfdsf
                                     </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
